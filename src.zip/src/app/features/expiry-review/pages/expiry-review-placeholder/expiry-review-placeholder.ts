import { Component } from '@angular/core';

@Component({
  selector: 'app-expiry-review-placeholder',
  standalone: true,
  template: `
    <h1 class="text-page-title text-text-primary">Expiry Review</h1>
    <p class="mt-2 text-body text-text-secondary">
      This feature will be implemented in a later task.
    </p>
  `,
})
export class ExpiryReviewPlaceholderComponent {}
