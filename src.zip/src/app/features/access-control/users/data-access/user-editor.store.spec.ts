import { HttpErrorResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of, Subject } from 'rxjs';
import { UserManagementApiService } from './user-management-api.service';
import { UserEditorStore } from './user-editor.store';

describe('UserEditorStore create mode', () => {
  const roles = [{
    id: 'role-1',
    name: 'Database Role',
    permissions: ['Client.View'],
    requiresMfa: false,
  }];
  const api = {
    listRoles: vi.fn(),
    createUser: vi.fn(),
  };
  const router = { navigate: vi.fn().mockResolvedValue(true) };

  beforeEach(() => {
    api.listRoles.mockReset().mockReturnValue(of(roles));
    api.createUser.mockReset().mockReturnValue(of({ id: 'created-user' }));
    router.navigate.mockClear();
    TestBed.configureTestingModule({
      providers: [
        UserEditorStore,
        { provide: UserManagementApiService, useValue: api },
        { provide: Router, useValue: router },
      ],
    });
  });

  it('loads roles, submits the focused contract once, and redirects to the editor', () => {
    const store = TestBed.inject(UserEditorStore);
    store.initializeCreate();
    store.updateCreateGeneral({
      firstName: ' Ada ',
      lastName: ' Lovelace ',
      email: ' ada@example.test ',
      phoneNumber: ' ',
      isActive: true,
    }, true);
    store.toggleRole('role-1', true);

    store.create();

    expect(api.listRoles).toHaveBeenCalledOnce();
    expect(api.createUser).toHaveBeenCalledWith({
      firstName: 'Ada',
      lastName: 'Lovelace',
      email: 'ada@example.test',
      phoneNumber: null,
      isActive: true,
      requiresMfa: false,
      mfaMethod: 'Authenticator',
      roleIds: ['role-1'],
    });
    expect(JSON.stringify(api.createUser.mock.calls[0][0]).toLocaleLowerCase())
      .not.toContain('password');
    expect(router.navigate).toHaveBeenCalledWith([
      '/access-control/users', 'created-user', 'general',
    ]);
  });

  it('requires General data and at least one role before calling the API', () => {
    const store = TestBed.inject(UserEditorStore);
    store.initializeCreate();

    store.create();
    expect(store.error()).toBe('invalidGeneral');
    expect(api.createUser).not.toHaveBeenCalled();

    store.updateCreateGeneral({
      firstName: 'Ada', lastName: 'Lovelace', email: 'ada@example.test',
      phoneNumber: '', isActive: true,
    }, true);
    store.create();
    expect(store.error()).toBe('invalidRoles');
    expect(api.createUser).not.toHaveBeenCalled();
  });

  it('prevents duplicate submissions and maps duplicate email safely', () => {
    const pending = new Subject<{ id: string }>();
    api.createUser.mockReturnValue(pending.asObservable());
    const store = TestBed.inject(UserEditorStore);
    store.initializeCreate();
    store.updateCreateGeneral({
      firstName: 'Ada', lastName: 'Lovelace', email: 'ada@example.test',
      phoneNumber: '', isActive: true,
    }, true);
    store.toggleRole('role-1', true);

    store.create();
    store.create();
    expect(api.createUser).toHaveBeenCalledOnce();
    pending.error(new HttpErrorResponse({
      status: 409,
      error: { type: 'urn:carecomply:problem:user-duplicate-email' },
    }));
    expect(store.error()).toBe('duplicateEmail');
  });

  it('supports explicit create-time MFA while preserving a role MFA floor', () => {
    const store = TestBed.inject(UserEditorStore);
    store.initializeCreate();
    store.setCreateMfa(true);
    store.setCreateMfaMethod('Email');
    expect(store.createRequiresMfa()).toBe(true);
    expect(store.createMfaMethod()).toBe('Email');

    store.setCreateMfa(false);
    expect(store.createRequiresMfa()).toBe(false);

    store.roles.set([{
      id: 'mfa-role', name: 'Protected role', permissions: ['User.Manage'], requiresMfa: true,
    }]);
    store.selectCreateRole('mfa-role');
    store.setCreateMfa(false);
    expect(store.createMfaRequiredByRoles()).toBe(true);
    expect(store.createRequiresMfa()).toBe(true);
  });
});
